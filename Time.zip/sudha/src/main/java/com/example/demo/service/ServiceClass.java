package com.example.demo.service;

import java.util.List;

import javax.persistence.Entity;

import com.example.demo.entity.EntityClass;


public interface ServiceClass {
	
	public EntityClass insert(EntityClass entityClass);
	public List<EntityClass> getAll();

}
